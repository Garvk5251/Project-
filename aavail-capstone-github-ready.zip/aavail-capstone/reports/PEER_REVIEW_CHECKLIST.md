# Peer-review evidence checklist

| Rubric question | Evidence |
|---|---|
| API unit tests | `tests/test_api.py` |
| Model unit tests | `tests/test_model.py` |
| Logging unit tests | `tests/test_logging.py` |
| Single command runs tests | `pytest -q` |
| Performance monitoring | `/monitoring/summary`, `src/monitoring.py` |
| Isolated test read/write | `tmp_path` and injected model/data fixtures |
| Specific-country and all-country predictions | `/predict`, `/predict/all` |
| Automated ingestion | `src/data_ingestion.py`, generator script |
| Multiple models compared | Random Forest vs 7-day seasonal-naive |
| EDA visualizations | `reports/figures/` after training |
| Docker image | `Dockerfile` |

The novelty utility is a simple feature-range alert, not a complete production drift system. For production, add delayed ground-truth collection and scheduled model-performance evaluation.
