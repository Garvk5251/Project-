# AAVAIL Revenue Forecasting Capstone

A containerized Flask API for daily revenue forecasts by country. The project demonstrates the AI workflow expected in the capstone: JSON ingestion, EDA, feature engineering, time-aware model evaluation, baseline comparison, API deployment, logging, monitoring and tests.

**Data disclaimer:** the sample-data generator creates synthetic AAVAIL-style transactions for demonstration. It is not the official course dataset and must not be presented as actual company findings. Replace it with the official JSON files before submission.

## Business framing
Forecast daily revenue for a requested country and date, or return forecasts for all countries combined. This is a supervised time-series regression problem.

## Setup
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_sample_data.py
python -m src.train
python app.py
```

## API
```bash
curl http://localhost:5000/health
curl -X POST http://localhost:5000/predict -H "Content-Type: application/json" -d '{"target_date":"2025-09-01","country":"Singapore"}'
curl -X POST http://localhost:5000/predict/all -H "Content-Type: application/json" -d '{"target_date":"2025-09-01"}'
curl http://localhost:5000/monitoring/summary
```
Minimum inputs for a single-country prediction: `target_date` and `country`. All-country prediction requires `target_date`.

## Tests
```bash
python -m pytest -q
```
Tests use temporary files and injected fixtures, not production model/log files.

## Docker
```bash
docker build -t aavail-revenue-forecast .
docker run --rm -p 5000:5000 aavail-revenue-forecast
```

## Design
Daily transaction records are aggregated by date and country. Features include day-of-week, month, day-of-year, weekend flag, revenue lags (1, 7, 14, 28 days) and rolling means (7, 28 days). A chronological 80/20 split is used. Random Forest is compared with a seasonal-naive 7-day-lag baseline using MAE, RMSE and MAPE. The model with lower validation MAE is selected. Forecasts beyond the last observed date are recursive, so uncertainty increases with horizon.

Each successful API request logs timestamp, request type, country, target date, prediction, model version and runtime. Raw customer identifiers and transaction payloads are not logged. The monitoring endpoint summarizes request count and runtime. `src/monitoring.py` contains a lightweight feature-novelty check.

## Before submitting
1. Replace synthetic JSON with the official AAVAIL transaction JSON files.
2. Confirm source schema and currency.
3. Re-run ingestion/training/tests and inspect generated charts and metrics.
4. Push source, tests, README and report figures to a public GitHub repository.
5. Do not commit credentials, private customer data, `.venv` or production logs.
