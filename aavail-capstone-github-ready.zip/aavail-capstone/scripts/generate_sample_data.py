from pathlib import Path
import json,numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def main():
    rng=np.random.default_rng(2026); countries={"Singapore":1.1,"United Kingdom":1.3,"USA":1.45,"EIRE":.72,"Germany":1.0}
    dates=pd.date_range("2024-01-01","2025-08-31",freq="D"); rows=[]; cid=0
    for country,mult in countries.items():
        for i,d in enumerate(dates):
            base=(145+.18*i)*mult*(1+.12*np.sin(2*np.pi*d.dayofweek/7))*(1+.16*np.sin(2*np.pi*d.dayofyear/365.25))+rng.normal(0,12)
            n=int(rng.integers(3,8)); weights=rng.dirichlet(np.ones(n))
            for j,w in enumerate(weights):
                cid+=1; rows.append({"date":d.strftime("%Y-%m-%d"),"country":country,
                  "revenue":round(float(max(30,base)*w),2),"purchases":1,
                  "stream_views":int(rng.integers(5,90)),"stream_id":f"{country[:2]}-{rng.integers(1,250):03d}",
                  "customer_id":f"C{cid}"})
    p=ROOT/"data/raw/sample_transactions.json"; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(rows,separators=(",",":"))); print("Generated",len(rows),"synthetic rows")
if __name__=="__main__": main()
