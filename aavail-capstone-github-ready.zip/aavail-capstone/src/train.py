from pathlib import Path
import json,joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .data_ingestion import ingest_json_directory
from .forecasting import train_and_evaluate
ROOT=Path(__file__).resolve().parents[1]
def main():
    daily=ingest_json_directory(ROOT/"data/raw",ROOT/"data/processed/daily_country_metrics.csv")
    fig=ROOT/"reports/figures"; fig.mkdir(parents=True,exist_ok=True)
    for metric,title,name in [("revenue","Daily revenue","revenue_by_country.png"),
      ("purchases","Daily purchases","purchases_by_country.png"),("total_views","Daily stream views","views_by_country.png")]:
        plt.figure(figsize=(10,4))
        for country,g in daily.groupby("country"): plt.plot(g.date,g[metric],label=country,linewidth=.8)
        plt.title(title+" by country"); plt.xlabel("Date"); plt.ylabel(metric); plt.legend()
        plt.tight_layout(); plt.savefig(fig/name,dpi=150); plt.close()
    artifact,report,preds=train_and_evaluate(daily)
    joblib.dump(artifact,ROOT/"models/forecast_model.joblib")
    (ROOT/"reports/metrics.json").write_text(json.dumps(report,indent=2))
    plt.figure(figsize=(7,4))
    plt.bar(["Random Forest","Seasonal naive (7-day)"],
      [report["random_forest"]["mae"],report["seasonal_naive_lag_7"]["mae"]])
    plt.ylabel("Validation MAE (lower is better)"); plt.title("Model vs baseline")
    plt.tight_layout(); plt.savefig(fig/"model_comparison.png",dpi=150); plt.close()
    print(json.dumps(report,indent=2)); print("Selected:",artifact["selected_model"])
if __name__=="__main__": main()
