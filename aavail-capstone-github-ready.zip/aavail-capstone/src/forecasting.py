import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from .features import FEATURES,make_supervised_frame,features_for_date

def metrics(y,p):
    y=np.asarray(y); p=np.asarray(p)
    return {"mae":float(mean_absolute_error(y,p)),
            "rmse":float(np.sqrt(mean_squared_error(y,p))),
            "mape_pct":float(np.mean(np.abs((y-p)/np.maximum(np.abs(y),1e-8)))*100)}

def train_and_evaluate(daily):
    frame=make_supervised_frame(daily)
    dates=sorted(frame.date.unique()); cutoff=dates[max(1,int(.8*len(dates)))]
    train=frame[frame.date<cutoff]; test=frame[frame.date>=cutoff]
    pre=ColumnTransformer([("country",OneHotEncoder(handle_unknown="ignore"),["country"]),
      ("numeric","passthrough",[c for c in FEATURES if c!="country"])])
    model=Pipeline([("pre",pre),("rf",RandomForestRegressor(n_estimators=220,
      max_depth=12,min_samples_leaf=2,random_state=42,n_jobs=-1))])
    model.fit(train[FEATURES],train.target)
    pred=model.predict(test[FEATURES]); base=test.lag_7.to_numpy()
    report={"random_forest":metrics(test.target,pred),
      "seasonal_naive_lag_7":metrics(test.target,base),
      "validation_start":str(pd.Timestamp(cutoff).date()),
      "training_rows":len(train),"validation_rows":len(test)}
    selected="random_forest" if report["random_forest"]["mae"]<=report["seasonal_naive_lag_7"]["mae"] else "seasonal_naive_lag_7"
    artifact={"model":model,"selected_model":selected,"feature_columns":FEATURES,
      "countries":sorted(daily.country.unique().tolist()),"model_version":"1.0.0"}
    return artifact,report,(test.target.to_numpy(),pred,base)

def predict_target(artifact,history,country,target_date):
    d=pd.Timestamp(target_date).normalize()
    h=history[history.country==country].sort_values("date")
    if h.empty: raise ValueError(f"Unknown country: {country}")
    last=pd.Timestamp(h.date.max()).normalize()
    if d<=last:
        row=features_for_date(history,country,d)
        if artifact["selected_model"]=="seasonal_naive_lag_7": return float(row["lag_7"])
        return float(artifact["model"].predict(pd.DataFrame([row])[artifact["feature_columns"]])[0])
    work=history.copy(); day=last+pd.Timedelta(days=1); pred=0
    while day<=d:
        row=features_for_date(work,country,day)
        if artifact["selected_model"]=="seasonal_naive_lag_7": pred=float(row["lag_7"])
        else: pred=float(artifact["model"].predict(pd.DataFrame([row])[artifact["feature_columns"]])[0])
        work=pd.concat([work,pd.DataFrame([{"date":day,"country":country,"revenue":max(0,pred)}])],ignore_index=True)
        day+=pd.Timedelta(days=1)
    return max(0,float(pred))
