from pathlib import Path
import json
import pandas as pd

REQUIRED = {"date", "country", "revenue", "purchases", "stream_views"}

def load_transactions(raw_dir):
    paths = sorted(Path(raw_dir).glob("*.json"))
    if not paths:
        raise FileNotFoundError(f"No JSON files found in {raw_dir}")
    frames = []
    for path in paths:
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(obj, dict):
                obj = obj.get("transactions", [obj])
            frames.append(pd.json_normalize(obj))
        except json.JSONDecodeError:
            frames.append(pd.read_json(path, lines=True))
    data = pd.concat(frames, ignore_index=True)
    missing = REQUIRED - set(data.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    data["date"] = pd.to_datetime(data["date"], errors="coerce").dt.normalize()
    data["country"] = data["country"].astype("string").str.strip()
    for col in ["revenue", "purchases", "stream_views"]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.dropna(subset=list(REQUIRED))
    data = data[data.country.ne("")]
    if data.empty:
        raise ValueError("No valid transaction records")
    return data

def aggregate_daily(data):
    agg = {"revenue":("revenue","sum"), "purchases":("purchases","sum"),
           "total_views":("stream_views","sum")}
    if "stream_id" in data: agg["unique_streams"] = ("stream_id","nunique")
    if "customer_id" in data: agg["unique_customers"] = ("customer_id","nunique")
    return (data.groupby(["date","country"],as_index=False).agg(**agg)
            .sort_values(["country","date"]).reset_index(drop=True))

def ingest_json_directory(raw_dir, output_csv=None):
    daily = aggregate_daily(load_transactions(raw_dir))
    if output_csv:
        Path(output_csv).parent.mkdir(parents=True, exist_ok=True)
        daily.to_csv(output_csv, index=False)
    return daily
