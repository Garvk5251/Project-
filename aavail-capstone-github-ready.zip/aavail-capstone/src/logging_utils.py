import json,os
from pathlib import Path
from datetime import datetime,timezone
from threading import Lock
_LOCK=Lock()
def write_prediction_log(event,log_path=None):
    p=Path(log_path or os.getenv("PREDICTION_LOG","logs/predictions.jsonl")); p.parent.mkdir(parents=True,exist_ok=True)
    row=dict(event); row.setdefault("timestamp",datetime.now(timezone.utc).isoformat())
    with _LOCK:
        with p.open("a",encoding="utf-8") as f: f.write(json.dumps(row,default=str)+"\n")
    return row
def read_prediction_logs(log_path=None):
    p=Path(log_path or os.getenv("PREDICTION_LOG","logs/predictions.jsonl"))
    if not p.exists(): return []
    out=[]
    for line in p.read_text(encoding="utf-8").splitlines():
        try: out.append(json.loads(line))
        except json.JSONDecodeError: pass
    return out
