import pandas as pd
FEATURES = ["country","day_of_week","month","day_of_year","is_weekend",
            "lag_1","lag_7","lag_14","lag_28","rolling_mean_7","rolling_mean_28"]

def make_supervised_frame(daily):
    rows=[]
    for country,g in daily.groupby("country"):
        g=g.sort_values("date").reset_index(drop=True); rev=g.revenue.astype(float)
        for i in range(28,len(g)):
            d=pd.Timestamp(g.loc[i,"date"]); p=rev.iloc[:i]
            rows.append({"date":d,"country":country,"day_of_week":d.dayofweek,
              "month":d.month,"day_of_year":d.dayofyear,"is_weekend":int(d.dayofweek>=5),
              "lag_1":p.iloc[-1],"lag_7":p.iloc[-7],"lag_14":p.iloc[-14],
              "lag_28":p.iloc[-28],"rolling_mean_7":p.iloc[-7:].mean(),
              "rolling_mean_28":p.iloc[-28:].mean(),"target":rev.iloc[i]})
    return pd.DataFrame(rows)

def features_for_date(history,country,target_date):
    d=pd.Timestamp(target_date).normalize()
    h=history[(history.country==country)&(history.date<d)].sort_values("date")
    if len(h)<28: raise ValueError(f"At least 28 days of history required for {country}")
    r=h.revenue.astype(float)
    return {"country":country,"day_of_week":d.dayofweek,"month":d.month,
      "day_of_year":d.dayofyear,"is_weekend":int(d.dayofweek>=5),
      "lag_1":r.iloc[-1],"lag_7":r.iloc[-7],"lag_14":r.iloc[-14],
      "lag_28":r.iloc[-28],"rolling_mean_7":r.iloc[-7:].mean(),
      "rolling_mean_28":r.iloc[-28:].mean()}
