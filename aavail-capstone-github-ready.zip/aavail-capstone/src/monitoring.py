import numpy as np
from .logging_utils import read_prediction_logs
def novelty_check(row,training_frame,columns,z_threshold=4.0):
    flags=[]
    for c in columns:
        if c=="country": continue
        vals=training_frame[c].astype(float); sd=float(vals.std(ddof=0))
        if sd and abs(float(row[c])-float(vals.mean()))/sd>z_threshold:
            flags.append({"feature":c,"z_score":round(abs(float(row[c])-float(vals.mean()))/sd,2)})
    return {"is_novel":bool(flags),"flags":flags}
def monitoring_summary(path=None):
    logs=read_prediction_logs(path)
    runtimes=[float(x["runtime_ms"]) for x in logs if "runtime_ms" in x]
    return {"request_count":len(logs),"mean_runtime_ms":round(float(np.mean(runtimes)),2) if runtimes else None,
      "latest_prediction":logs[-1].get("timestamp") if logs else None,
      "countries_seen":sorted({x.get("country") for x in logs if x.get("country")})}
