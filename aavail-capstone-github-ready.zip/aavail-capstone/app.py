from pathlib import Path
import os,time,joblib,pandas as pd
from flask import Flask,jsonify,request
from src.forecasting import predict_target
from src.logging_utils import write_prediction_log
from src.monitoring import monitoring_summary
ROOT=Path(__file__).resolve().parent
MODEL=Path(os.getenv("MODEL_PATH",ROOT/"models/forecast_model.joblib"))
DATA=Path(os.getenv("DAILY_DATA_PATH",ROOT/"data/processed/daily_country_metrics.csv"))
LOG=Path(os.getenv("PREDICTION_LOG",ROOT/"logs/predictions.jsonl"))
def create_app(model_artifact=None,history=None,log_path=None):
    app=Flask(__name__); artifact=model_artifact; daily=history.copy() if history is not None else None; log=log_path or LOG
    def resources():
        nonlocal artifact,daily
        if artifact is None:
            if not MODEL.exists(): raise RuntimeError("Train model first: python -m src.train")
            artifact=joblib.load(MODEL)
        if daily is None:
            if not DATA.exists(): raise RuntimeError("Processed data missing; train first")
            daily=pd.read_csv(DATA,parse_dates=["date"])
        return artifact,daily
    def payload(data,need_country):
        if not isinstance(data,dict): return None,"JSON object required"
        if not data.get("target_date"): return None,"target_date is required"
        try: d=pd.to_datetime(data["target_date"],errors="raise").normalize()
        except Exception: return None,"target_date must be a valid date"
        c=data.get("country")
        if need_country and (not isinstance(c,str) or not c.strip()): return None,"country is required"
        return {"date":d,"country":c.strip() if isinstance(c,str) else None},None
    @app.get("/health")
    def health():
        try:
            a,_=resources(); return jsonify({"status":"ok","model_version":a.get("model_version")})
        except Exception as e: return jsonify({"status":"not_ready","error":str(e)}),503
    @app.post("/predict")
    def predict():
        start=time.perf_counter(); v,e=payload(request.get_json(silent=True),True)
        if e:return jsonify({"error":e}),400
        try:
            a,h=resources()
            if v["country"] not in a["countries"]: return jsonify({"error":"Unknown country","available_countries":a["countries"]}),400
            y=predict_target(a,h,v["country"],v["date"]); ms=(time.perf_counter()-start)*1000
            write_prediction_log({"request_type":"single_country","country":v["country"],"target_date":str(v["date"].date()),
              "prediction":round(y,2),"model_version":a["model_version"],"runtime_ms":round(ms,2)},log)
            return jsonify({"country":v["country"],"target_date":str(v["date"].date()),"predicted_revenue":round(y,2),
              "currency":"USD (synthetic sample)","model":a["selected_model"],"model_version":a["model_version"],"runtime_ms":round(ms,2)})
        except ValueError as ex:return jsonify({"error":str(ex)}),400
        except Exception as ex:app.logger.exception("forecast error");return jsonify({"error":str(ex)}),503
    @app.post("/predict/all")
    def predict_all():
        start=time.perf_counter(); v,e=payload(request.get_json(silent=True),False)
        if e:return jsonify({"error":e}),400
        try:
            a,h=resources(); result={c:round(predict_target(a,h,c,v["date"]),2) for c in a["countries"]}
            ms=(time.perf_counter()-start)*1000
            write_prediction_log({"request_type":"all_countries","country":"ALL","target_date":str(v["date"].date()),
              "prediction":round(sum(result.values()),2),"model_version":a["model_version"],"runtime_ms":round(ms,2)},log)
            return jsonify({"target_date":str(v["date"].date()),"predicted_revenue_by_country":result,
              "total_predicted_revenue":round(sum(result.values()),2),"currency":"USD (synthetic sample)",
              "model":a["selected_model"],"model_version":a["model_version"],"runtime_ms":round(ms,2)})
        except ValueError as ex:return jsonify({"error":str(ex)}),400
        except Exception as ex:app.logger.exception("forecast error");return jsonify({"error":str(ex)}),503
    @app.get("/monitoring/summary")
    def monitor():return jsonify(monitoring_summary(log))
    return app
app=create_app()
if __name__=="__main__":app.run(host="0.0.0.0",port=int(os.getenv("PORT",5000)),debug=False)
