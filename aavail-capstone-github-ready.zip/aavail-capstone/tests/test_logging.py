from src.logging_utils import write_prediction_log,read_prediction_logs
def test_jsonl_log(tmp_path):
    p=tmp_path/"test.jsonl"; write_prediction_log({"country":"Singapore","runtime_ms":3},p)
    rows=read_prediction_logs(p); assert len(rows)==1 and rows[0]["country"]=="Singapore" and "timestamp" in rows[0]
