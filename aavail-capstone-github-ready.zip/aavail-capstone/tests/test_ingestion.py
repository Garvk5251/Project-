import json
from src.data_ingestion import load_transactions,aggregate_daily
def test_json_ingestion_aggregation(tmp_path):
    rows=[{"date":"2025-01-01","country":"Singapore","revenue":10,"purchases":1,"stream_views":5,"stream_id":"a","customer_id":"x"},
      {"date":"2025-01-01","country":"Singapore","revenue":20,"purchases":1,"stream_views":7,"stream_id":"b","customer_id":"x"}]
    (tmp_path/"x.json").write_text(json.dumps(rows))
    daily=aggregate_daily(load_transactions(tmp_path))
    assert len(daily)==1 and daily.iloc[0].revenue==30 and daily.iloc[0].total_views==12
    assert daily.iloc[0].unique_customers==1
