from app import create_app
def test_country_api_and_monitoring(dummy_artifact,sample_history,tmp_path):
    app=create_app(dummy_artifact,sample_history,tmp_path/"log.jsonl"); client=app.test_client()
    r=client.post("/predict",json={"target_date":"2024-03-15","country":"Singapore"})
    assert r.status_code==200 and r.get_json()["predicted_revenue"]==125
    assert client.get("/monitoring/summary").get_json()["request_count"]==1
def test_all_country_api(dummy_artifact,sample_history,tmp_path):
    client=create_app(dummy_artifact,sample_history,tmp_path/"all.jsonl").test_client()
    r=client.post("/predict/all",json={"target_date":"2024-03-15"})
    assert r.status_code==200 and set(r.get_json()["predicted_revenue_by_country"])=={"Singapore","USA"}
def test_required_fields(dummy_artifact,sample_history,tmp_path):
    c=create_app(dummy_artifact,sample_history,tmp_path/"x.jsonl").test_client()
    assert c.post("/predict",json={"country":"Singapore"}).status_code==400
