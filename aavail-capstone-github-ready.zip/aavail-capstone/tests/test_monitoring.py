import pandas as pd
from src.monitoring import novelty_check
def test_novelty_flags_extreme_input():
    train=pd.DataFrame({"country":["SG"]*5,"lag_1":[99,100,101,100,102]})
    assert novelty_check({"country":"SG","lag_1":10000},train,["country","lag_1"])["is_novel"]
