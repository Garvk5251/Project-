import pandas as pd
from src.features import make_supervised_frame,features_for_date
from src.forecasting import predict_target
def test_features_use_past_only(sample_history):
    f=make_supervised_frame(sample_history); assert not f.empty
    row=features_for_date(sample_history,"Singapore","2024-03-15")
    assert row["lag_1"]==sample_history[(sample_history.country=="Singapore")&(sample_history.date<pd.Timestamp("2024-03-15"))].sort_values("date").iloc[-1].revenue
def test_future_prediction(dummy_artifact,sample_history):
    assert predict_target(dummy_artifact,sample_history,"Singapore","2024-03-15")==125
