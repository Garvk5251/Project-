import numpy as np,pandas as pd,pytest
@pytest.fixture
def sample_history():
    dates=pd.date_range("2024-01-01",periods=70)
    return pd.DataFrame([{"date":d,"country":c,"revenue":100*m+i*.4+(i%7)*2}
      for c,m in [("Singapore",1),("USA",1.3)] for i,d in enumerate(dates)])
@pytest.fixture
def dummy_artifact():
    class Model:
        def predict(self,x):return np.array([125.]*len(x))
    return {"model":Model(),"selected_model":"random_forest",
      "feature_columns":["country","day_of_week","month","day_of_year","is_weekend","lag_1","lag_7","lag_14","lag_28","rolling_mean_7","rolling_mean_28"],
      "countries":["Singapore","USA"],"model_version":"test-1"}
